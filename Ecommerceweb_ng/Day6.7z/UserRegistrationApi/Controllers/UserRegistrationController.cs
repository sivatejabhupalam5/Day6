using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using UserRegistrationApi.Models;

namespace UserRegistrationApi.Controllers
{
    [ApiController]
    [EnableCors("UserRegistrationPolicy")]
    [Route("api/[controller]")]
    public class UserRegistrationController : ControllerBase
    {
        private readonly string _filePath = "../Data/users.json";

        [HttpPost]
        public IActionResult Register(User user)
        {
            if (user == null)
            {
                return BadRequest();
            }

            var users = GetUsers();

            // Increment the ID using LINQ
            user.ID = users.Any() ? users.Max(u => u.ID) + 1 : 1;

            users.Add(user);
            SaveUsers(users);

            return Ok(user);
        }

        [HttpGet]
        [Route("Getuser")]
        public IActionResult Getuser()
        {
            var users = GetUsers();
            return Ok(users);
        }

        private List<User> GetUsers()
        {
            if (!System.IO.File.Exists(_filePath))
            {
                return new List<User>();
            }

            var json = System.IO.File.ReadAllText(_filePath);
            return JsonSerializer.Deserialize<List<User>>(json);
        }

        private void SaveUsers(List<User> users)
        {
            var json = JsonSerializer.Serialize(users);
            System.IO.File.WriteAllText(_filePath, json);
        }
    }
}